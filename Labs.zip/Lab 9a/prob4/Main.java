package prob4;

import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class Main
{

    public static void main(String [] args){
        PrimeStream ps = new PrimeStream(); //PrimeStream is enclosing class
        ps.printFirstNPrimes(10);
        System.out.println("====");
        ps.printFirstNPrimes(5);
    }
}
