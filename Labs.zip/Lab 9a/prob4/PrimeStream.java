package prob4;

import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class PrimeStream
{

    public void printFirstNPrimes(long num)
    {
        final Stream<Integer> primes = Stream.iterate(2, n -> nextPrime(n));
        primes.forEach(System.out::println);
    }

    public int nextPrime(int n)
    {
        while (true)
        {
            n++;
            if (isPrime(n))
                return n;
        }
    }
    public boolean isPrime(Integer integer)
    {
        if(integer%2==0)
            return false;
        else {
            for(int i=1; i<integer/2; i=i+2){
                if(integer%i==0)
                    return false;
            }
        }
        return true;
    }

}

