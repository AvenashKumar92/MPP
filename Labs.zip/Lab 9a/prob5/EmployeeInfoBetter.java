package prob5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.function.*;


final public class EmployeeInfoBetter {
	public class Pair<T,S> {
		private final T first;
		private final S second;
		public Pair(T t, S s) {
			this.first = t;
			this.second = s;
		}
		final public T getFirst() {
			return first;
		}
		final public S getSecond() {
			return second;
		}
	}
	
	enum SortMethod {BYNAME, BYSALARY};
	Function<Employee, String> byName = e -> e.getName();
	Function<Employee, Integer> bySalary = e -> e.getSalary();

	HashMap<SortMethod, Pair> sortMap = new HashMap<SortMethod, Pair>();
	
	public EmployeeInfoBetter() {
		sortMap.put(SortMethod.BYNAME, new Pair(byName, bySalary));
		sortMap.put(SortMethod.BYSALARY, new Pair(bySalary, byName));
	}
	
	public void sort(List<Employee> emps, final SortMethod method) {
		Collections.sort(emps, Comparator.comparing((Function)sortMap.get(method).getFirst())
				.thenComparing((Function)sortMap.get(method).getSecond()));
	}

	public static void main(String[] args) {
		List<Employee> emps = new ArrayList<>();
		emps.add(new Employee("Joe", 100000));
		emps.add(new Employee("Tim", 50000));
		emps.add(new Employee("Rick", 50000));
		emps.add(new Employee("Andy", 60000));
		emps.add(new Employee("Tim", 10000));
		EmployeeInfoBetter ei = new EmployeeInfoBetter();
		ei.sort(emps, SortMethod.BYNAME);
		System.out.println(emps);
		//same instance
		ei.sort(emps, SortMethod.BYSALARY);
		System.out.println(emps);
	}
}
