package Lab5.prob2;

public final class Rectangle implements Shape {

	private final double width;
	final private double length;
	
	
	public Rectangle(final double width, final double length) {
		this.width = width;
		this.length = length;
	}
	
	


	public double getWidth() {
		return width;
	}




	public double getLength() {
		return length;
	}




	public double computeArea() {
		return width*length;
	}

}
