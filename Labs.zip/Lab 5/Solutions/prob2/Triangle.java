package Lab5.prob2;

public final class Triangle implements Shape {

	private final double height;
	private final double base;
	
	
	
	public Triangle(double height, double base) {
		this.height = height;
		this.base = base;
	}



	public double getHeight() {
		return height;
	}



	public double getBase() {
		return base;
	}



	public double computeArea() {
		return (height*base)/2;
	}

}
