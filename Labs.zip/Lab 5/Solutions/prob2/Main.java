package Lab5.prob2;


public class Main 
{
	static Shape shapes[]={new Circle(2), new Triangle(2, 3), new Rectangle(2,3)};
    public static void main( String[] args )
    {
		double sumOfArea=0.0;
		
    	for(Shape s: shapes){
    		sumOfArea+=s.computeArea();
    	}
        System.out.println( "Sum of Areas = " + sumOfArea);
    }
}
