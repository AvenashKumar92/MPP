package Lab5.prob3;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CustOrderFactory {
	
	private CustOrderFactory(){}
	
	public static void newItem(Customer customer, LocalDate orderDate, String itemName) {
		
		Order order=findCustomerOrder(customer,orderDate);
		if(order==null){
			order=Order.newOrder(customer, orderDate);
			order.addItem(itemName);
			return;
		}
		
		Item item=findItem(order, itemName);
		if(item==null){
			order.addItem(itemName);
			return;
		}
	}
	
	
	
	private static Order findCustomerOrder(Customer customer, LocalDate orderDate) {
		for(Order order:customer.getOrders()){
				if(order.getOrderDate().equals(orderDate)){
					return order;
				}
		}
		return null;
	}

	
	public static Customer createCustomer(String name) {
		return new Customer(name);
	}
	
	//Because order should not exist without item
	public static Order addOrder(Customer customer, LocalDate orderDate, String itemName) {
		
		Order order=findCustomerOrder(customer, orderDate);
		if(order!=null)
			return order;
		
		Order newOrder= Order.newOrder(customer, orderDate);
		newOrder.addItem(itemName);
		
		return newOrder;
	}

	public static Item findItem(Order order, String name) {
		for(Item item: order.getItems()) {
			if(item.name.equals(name)) {
				return item;
			}
		}
		return null;
	}
	public static Order findCustomerOrder(Customer customer, Order order) {
		for(Order o: customer.getOrders()) {
			if(o.getOrderDate().equals(order.getOrderDate())) {
				return o;
			}
		}
		return null;
	}
}
