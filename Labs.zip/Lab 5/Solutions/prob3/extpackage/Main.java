package Lab5.prob3.extpackage;

import java.time.LocalDate;

import Lab5.prob3.*;

public class Main {
	public static void main(String[] args) {
		/*Customer cust = new Customer("Bob");
		Order order = Order.newOrder(cust, LocalDate.now());
		order.addItem("Shirt");
		order.addItem("Laptop");

		order = Order.newOrder(cust, LocalDate.now());
		order.addItem("Pants");
		order.addItem("Knife set");

		System.out.println(cust.getOrders());*/
		
		
		//Create Customer
		Customer customer=CustOrderFactory.createCustomer("Bob");
		
		/**
		 * addOrder add new item in existing order list of customer
		 */
		Order todaysOrder = CustOrderFactory.addOrder(customer, LocalDate.now(), "Cell Phone");
		todaysOrder.addItem("Shirt");
		todaysOrder.addItem("Laptop");
		todaysOrder.addItem("Pants");
		todaysOrder.addItem("Knife set");
		
		
		//Same customer but different orders on different date
		Order yesterdayOrder = CustOrderFactory.addOrder(customer, LocalDate.now().minusDays(1), "Blanket");
		yesterdayOrder.addItem("Apples");
		yesterdayOrder.addItem("Watch");
		yesterdayOrder.addItem("Pencils");
		yesterdayOrder.addItem("Meat");
		
		//Print all orders of customer
		System.out.println("Bob orders list:");
		System.out.println(customer.getOrders());
		
		//Print today's order
		System.out.println("Bob today's order");
		System.out.println(todaysOrder);
		
		//Print yesterday order
		System.out.println("Bob yesterday's order");
		System.out.println(yesterdayOrder);
	}
}

		
