package Lab5.prob1.rulesets;

import java.awt.Component;

public interface RuleSet {
	public void applyRules(Component ob) throws RuleException;
	public static double MIN_PRICE_THRESHOLD=0.49;
	default void priceGreaterThanThreshold(double price) throws RuleException {
		if(price<=0.49)
			throw new RuleException("Price must be a number greater than "+MIN_PRICE_THRESHOLD);
	}

	default void priceFloatAndThresholdRule(String price) throws RuleException {
		String val = price.trim();
		String errorMessage="Price must be a floating point number with two decimal places";
		double priceInDecimal=0.0;
		
		//Rule 2.1: Price must be a floating point number with two decimal places
		try {
			priceInDecimal=Double.parseDouble(val);
		} catch(NumberFormatException e) {
			throw new RuleException(errorMessage);
		}
		
		int decimalIndex = val.indexOf('.');
		
		//When price is given in whole number
		if(decimalIndex==-1)
			return;
		
		String numbersAfterDecimal=val.substring(decimalIndex+1);
		if(numbersAfterDecimal.length()>2)
			throw new RuleException(errorMessage);
		
		//Rule 3: Price must be a number greater than 0.49
		priceGreaterThanThreshold(priceInDecimal);
	}
}
