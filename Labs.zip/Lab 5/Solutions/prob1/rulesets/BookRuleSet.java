package Lab5.prob1.rulesets;

import java.awt.Component;
import java.math.BigInteger;
import java.util.Arrays;

import Lab5.prob1.gui.BookWindow;
import Lab5.prob1.gui.CDWindow;
import Lab5.prob1.rulesets.RuleSet;
//import Lab5.prob1.gui.*;


/**
 * Rules:
 * 1. All fields must be nonempty
 * 2. Isbn must be numeric and consist of either 10 or 13 characters
 * 3. If Isbn has length 10, the first digit must be 0 or 1
 * 4. If Isbn has length 13, the first 3 digits must be either 978 or 979
 * 5. Price must be a floating point number with two decimal places 
 * 6. Price must be a number greater than 0.49.
 *
 */
public class BookRuleSet implements RuleSet {

	private BookWindow bookWindow;
	private final static int [] ISBN_ACCEPTABLE_LENGTHS={10,13};

	public void applyRules(Component ob) throws RuleException {
		bookWindow = (BookWindow)ob;
		nonemptyRule();
		isbnNumbericRule();
		isbnLength10Rule();
		isbnLength13Rule();
		priceFloatAndThresholdRule(bookWindow.getPriceValue());
	}

	private void isbnLength10Rule() throws RuleException {
		//Rule 3: If Isbn has length 10, the first digit must be 0 or 1
		String inputIsbn=bookWindow.getIsbnValue().trim();
		if(inputIsbn.length() == ISBN_ACCEPTABLE_LENGTHS[0]){
			if(!(inputIsbn.charAt(0) == '0' || inputIsbn.charAt(0) == '1')){
				throw new RuleException("Isbn has length 10, the first digit must be 0 or 1");
			}
		}
	}
	private void isbnLength13Rule() throws RuleException {
		//Rule 4: If Isbn has length 13, the first 3 digits must be either 978 or 979
		String inputIsbn=bookWindow.getIsbnValue().trim();
		if(inputIsbn.length() == ISBN_ACCEPTABLE_LENGTHS[1]){
			if(inputIsbn.substring(0, 3).equals("978") || inputIsbn.substring(0, 3).equals("979")){
				return;
			}
			throw new RuleException("Isbn has length 13, the first 3 digits must be either 978 or 979");
		}
	}
	private void isbnNumbericRule() throws RuleException{
		String inputIsbn=bookWindow.getIsbnValue().trim();
		try{
			//Rule 2.1: Isbn must be consist of either 10 or 13 characters
			if((ISBN_ACCEPTABLE_LENGTHS[0] == inputIsbn.length() || 
					ISBN_ACCEPTABLE_LENGTHS[1] == inputIsbn.length()) == false ){
				throw new NumberFormatException();
			}
				
			//Rule 2.2: Isbn must be numeric
			new BigInteger(inputIsbn);
		}
		catch (NumberFormatException e){
			throw new RuleException("Isbn must be numeric and consist of either 10 or 13 characters");
		}
	}
	private void nonemptyRule() throws RuleException{
		if(bookWindow.getIsbnValue().trim().isEmpty() ||
				bookWindow.getPriceValue().trim().isEmpty() ||
				bookWindow.getTitleValue().trim().isEmpty())
			throw new RuleException("All fields must be nonempty");
	}

	
}
