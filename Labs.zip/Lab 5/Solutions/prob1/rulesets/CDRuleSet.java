package Lab5.prob1.rulesets;

import java.awt.Component;

import Lab5.prob1.gui.*;

/**
 * Rules:
 *  1. All fields must be nonempty 
 *  2. Price must be a floating point number with two decimal places 
 *  3. Price must be a number greater than 0.49. 
 */

public class CDRuleSet implements RuleSet {

	private CDWindow cdWindow;
	final double minPriceThreshold = 0.49;
	
	//@Override
	public void applyRules(Component ob) throws RuleException {
		cdWindow = (CDWindow)ob;
		nonemptyRule();
		priceFloatAndThresholdRule(cdWindow.getPriceValue());
	}

	private void nonemptyRule() throws RuleException {
		if(cdWindow.getArtistValue().trim().isEmpty() || 
				cdWindow.getTitleValue().trim().isEmpty() ||
				cdWindow.getPriceValue().trim().isEmpty())
			throw new RuleException("All fields must be nonempty");
		
	}
	
}
