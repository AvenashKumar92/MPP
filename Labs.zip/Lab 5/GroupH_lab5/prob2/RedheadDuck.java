package lab5prob2;

public class RedheadDuck extends Duck {

	public RedheadDuck() {
		super(new FlyWithWings(), new Quack());
	}

	@Override
	public void display() {
		System.out.println("Red head duck duck will be shown");
	}

}
