package lab5prob2;

public interface QuackBehavior {
	void quack();
}
