package lab5prob2;

public abstract class Duck {
	 FlyBehavior f;
	 QuackBehavior q;
	 
	public Duck(FlyBehavior f, QuackBehavior q) {
		super();
		this.f = f;
		this.q = q;
	}

	public abstract void display();

	public void swim() {
		System.out.println("can swim");
	}
	public void quack() {
		q.quack();
	}
	public void fly() {
		f.fly();
	}
}