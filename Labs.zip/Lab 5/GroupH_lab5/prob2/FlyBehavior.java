package lab5prob2;

public interface FlyBehavior  {
	public void fly();
}
