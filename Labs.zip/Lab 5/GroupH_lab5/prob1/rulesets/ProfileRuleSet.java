package mpp.lesson5.prob1.rulesets;
import java.awt.Component;

import mpp.lesson5.prob1.ProfileWindow;



public class ProfileRuleSet implements RuleSet{

	@Override
	public void applyRules(Component ob) throws RuleException {
		String msg = "";
		ProfileWindow proWin = (ProfileWindow)ob;
		int count=0;
		String name = proWin.getIdValue();
		String firstName = proWin.getFirstNameValue();
		String lastName = proWin.getLastNameValue();
		String favoriteMovie = proWin.getFavoriteMovieValue();
		String favoriteRest = proWin.getFavoriteRestaurantValue();



		if(name.trim().length()==0){
			count++;
			msg+= "Please enter ID\n";
		}else{
			 try{
		         Integer.parseInt(name);
		      }
		      catch (NumberFormatException ex){
		    	  count++;
		    	  msg+= "Please enter a Numeric ID\n";
		      }
		}

		if(firstName.trim().length()==0){
			count++;
			msg+= "Please enter First Name\n";
		}else if(!(firstName.contains("[a-zA-Z]+") == false&&(lastName.contains("[a-zA-Z]+") == false))){
			count++;
			msg+= "Please enter valid first names in the range A-Z\n";
		}

		if(lastName.trim().length()==0){
			count++;
			msg+= "Please enter Last Name\n";
		}else if(!(firstName.contains("[a-zA-Z]+") == false&&(lastName.contains("[a-zA-Z]+") == false))){
			count++;
			msg+= "Please enter last names in the range A-Z\n";
	}

		if(favoriteMovie.trim().length()!=0 &&favoriteRest.trim().length()!=0){
			//count++;
			//msg+= "Please enter Favorite Movie\n";
			if(favoriteMovie.equalsIgnoreCase(favoriteRest)){
				count++;
				msg+="Favorite Movie and Favorite Restaurant cannot be equal";
			}
		}

		if(favoriteMovie.trim().length()==0){
			count++;
			msg+= "Please enter Favorite Movie\n";
		}
		if(favoriteRest.trim().length()==0){
			count++;
			msg+= "Please enter Favorite Restaurant\n";
		}
		/*if(favoriteMovie.equalsIgnoreCase(favoriteRest)){
			count++;
			msg+="Favorite Movie and Favorite Restaurant cannot be equal";
		}*/
		if(count>0){
			throw new RuleException(msg);
		}
	}

}
