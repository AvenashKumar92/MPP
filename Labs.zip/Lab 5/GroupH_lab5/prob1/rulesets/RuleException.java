package mpp.lesson5.prob1.rulesets;

public class RuleException  extends Exception {
	public RuleException() {
		super();
	}
	public RuleException(String msg) {
		super(msg);
	}
}