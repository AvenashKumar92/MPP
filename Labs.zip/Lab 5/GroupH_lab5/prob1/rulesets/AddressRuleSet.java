package mpp.lesson5.prob1.rulesets;

import java.awt.Component;

import mpp.lesson5.prob1.AddrWindow;



public class AddressRuleSet implements RuleSet{

	@Override
	public void applyRules(Component ob) throws RuleException {
		String msg = "";
		AddrWindow adrWin = (AddrWindow)ob;
		int count=0;
		String name = adrWin.getIdValue();
		if(name.trim().length()==0){
			count++;
			msg+= "Please enter ID\n";
		}else{
			 try{
		         Integer.parseInt(name);
		      }
		      catch (NumberFormatException ex){
		    	  count++;
		    	  msg+= "Please enter a Numeric ID\n";
		      }
		}

		String street = adrWin.getStreetValue();
		if(street.trim().length()==0){
			count++;
			msg+= "Please enter Street\n";
		}
		String city = adrWin.getCityValue();
		if(city.trim().length()==0){
			count++;
			msg+= "Please enter City\n";
		}
		String state = adrWin.getStateValue();
		if(state.trim().length()==0){
			count++;
			msg+= "Please enter State\n";
		}else if((state.trim().charAt(0)>='a'&&state.trim().charAt(0)<='z' || state.trim().charAt(0)>='A'&&state.trim().charAt(0)<='Z')){
			if(state.trim().length()!=2){
				count++;
				msg+= "Please enter valid state: two characters in the range A-Z\n";
			}
		}

		String zip = adrWin.getZipValue();
		int intZip = 0;
		if(zip.trim().length()==0){
			count++;
			msg+= "Please enter ZIP\n";
		}else{
			if(zip.length()!=5){
				count++;
				 msg+= "Please enter a 5 digit ZIP\n";
			}
			if(zip.equalsIgnoreCase(name)){
				count++;
				msg+= "Please enter a valid ZIP: ID field may not equal ZIP\n";
			}
			try{
				intZip = Integer.parseInt(zip);
		      }
		      catch (NumberFormatException ex){
		    	  count++;
		    	  msg+= "Please enter a Numeric ZIP\n";
		      }
		}
		if(count>0){
			throw new RuleException(msg);
		}
	}
}
