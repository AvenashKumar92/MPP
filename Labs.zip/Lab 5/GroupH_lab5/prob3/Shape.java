package lesson5lab.prob3;

public interface Shape {
	public abstract double computeArea();
}
