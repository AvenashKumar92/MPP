package lesson5lab.prob3;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Main {

	public static void main(String[] args) {
		NumberFormat formatter = new DecimalFormat("#0.00");
		Shape[] shape = { new Rectangle(10, 8), new Circle(5), new Triangle(12, 6) };
		double totArea = 0.0;
		for (Shape s : shape) {
			totArea += s.computeArea();

		}

		System.out.println(formatter.format(totArea));
	}

}
