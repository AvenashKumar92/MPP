package lesson2.labsolns.prob2A_externally_owned_two_setters;

public class StudentAndReport {
	public Student student;
	public GradeReport report;
	StudentAndReport(Student s, GradeReport g) {
		student = s;
		report = g;
	}
}
