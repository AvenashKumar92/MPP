package prob2B;

public class App 
{
    public static void main( String[] args )
    {
        Order order=new Order();
        order.createListOfOrderLine();
        OrderLine orderLine=new OrderLine();
        orderLine.createOrder();
    }
}
