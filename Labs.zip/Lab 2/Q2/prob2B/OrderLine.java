package prob2B;

public class OrderLine {
	
	private int orderNum;
	
	private Order order;

	
	void createOrder()
	{
		order=new Order();
		System.out.println("Create instance of Order via OrderLine class.");
	}


	public int getOrderNum() {
		return orderNum;
	}


	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}


	public Order getOrder() {
		return order;
	}


	public void setOrder(Order order) {
		this.order = order;
	}
	
}
