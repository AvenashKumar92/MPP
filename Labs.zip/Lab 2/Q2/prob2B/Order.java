package prob2B;

import java.util.ArrayList;
import java.util.List;

public class Order {
	List<OrderLine> orderLine;


	
	public void createListOfOrderLine()
	{
		orderLine=new ArrayList<OrderLine>();
		System.out.println("Create list of OrderLine via Order class.");
	}
}
