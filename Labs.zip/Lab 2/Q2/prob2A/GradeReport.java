package Lab2.prob2A;

public class GradeReport {
	Student stduent;

	public void createStudent()
	{
		stduent=new Student();
		System.out.println("Create instance of Student via GradeReport class.");
	}
}
