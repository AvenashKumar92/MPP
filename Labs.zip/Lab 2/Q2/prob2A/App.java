package Lab2.prob2A;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        GradeReport gradeReport=new GradeReport();
        gradeReport.createStudent();
        Student student=new Student();
        student.createGradeReport();
    }
}
