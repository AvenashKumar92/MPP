package Lab2.prob2A;

public class Student {
	
	private String name;
	
	private GradeReport gradeReport;

	
	void createGradeReport()
	{
		gradeReport=new GradeReport();
		System.out.println("Create instance of GradeReport via Student class.");
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public GradeReport getGradeReport() {
		return gradeReport;
	}

	public void setGradeReport(GradeReport gradeReport) {
		this.gradeReport = gradeReport;
	}
	
	
}
