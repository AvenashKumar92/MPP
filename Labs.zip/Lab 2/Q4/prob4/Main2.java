package lesson2.labs.prob4;

import java.util.ArrayList;
import java.util.List;

public class Main2 {
	
	Student bob;
	Student tim ;
	Student allen;
	Section bio1;
	Section bio2;
	Section math;
	
	public static void main(String [] args)
	{
		Main2 m = new Main2();
		m.readDataFromDb();
		
		
		
		System.out.println(m.bob.getTranscript());
		System.out.println("Grades for math section:\n " + m.getGrades(m.math));
		System.out.println("Courses that Tim took: " + m.getCourseNames(m.tim));
		System.out.println("Students who got A's: " + m.getStudentsWith("A"));
	}
	
	void readDataFromDb()
	{
		StudentSectionFactory studentSectionFactory;
		studentSectionFactory=new StudentSectionFactory();
		bio1 = studentSectionFactory.createSection(1, "Biology");
		bio2 = studentSectionFactory.createSection(2, "Biology");
		math = studentSectionFactory.createSection(3, "Mathematics");
		
		bob = studentSectionFactory.createStudent("1","Bob");
		tim = studentSectionFactory.createStudent("2", "Tim");
		allen = studentSectionFactory.createStudent("3", "Allen");
		
		//Student: Bob
		studentSectionFactory.newTranscriptEntry(bob, bio1, "A");
		studentSectionFactory.newTranscriptEntry(bob, math, "B");
		
		//Student: Tim
		studentSectionFactory.newTranscriptEntry(tim, bio1, "B+");
		studentSectionFactory.newTranscriptEntry(tim, math, "A-");
		
		//Student: Allen
		studentSectionFactory.newTranscriptEntry(allen, math, "B");
		studentSectionFactory.newTranscriptEntry(allen, bio2, "B+");
	}
	
	
	private void printTranscript(Student student)
	{
		System.out.println(student.getTranscript());
		
	}
	
	private List<String> getGrades(Section s) {
		List<String> grades  = new ArrayList<String>();
		for(TranscriptEntry t : s.gradeSheet) {
			grades.add(t.grade);
		}
		return grades;
	}
	private List<String> getCourseNames(Student s) {
		List<TranscriptEntry> all = s.grades;
		List<String> courseNames = new ArrayList<String>();
		for(TranscriptEntry te : all) {
			courseNames.add(te.section.courseName);
		}
		return courseNames;
	}
	private List<String> getStudentsWith(String grade) {
		List<String> studentNames = new ArrayList<String>();
		
		Student [] students = {bob, tim, allen};
		for(Student s : students) {
			boolean found = false;
			for(TranscriptEntry te : s.grades) {
				if(!found) {
					if(te.grade.equals(grade)) {
						found = true;
						studentNames.add(s.name);
					}
				}
			}
		}
		return studentNames;
	}
}
