package lesson2.labs.prob4;

import java.util.ArrayList;
import java.util.List;

public class StudentSectionFactory {
	
	public Student createStudent(String id, String name){
		return new Student(id, name);
	}
	
	public Section createSection(int secNum, String courseName){
		return new Section(secNum, courseName);
	}

	public void newTranscriptEntry(Student s, Section sect, String grade)
	{
		TranscriptEntry tEntry=new TranscriptEntry(s, sect, grade);
		s.grades.add(tEntry);
		sect.gradeSheet.add(tEntry);
	}
}
