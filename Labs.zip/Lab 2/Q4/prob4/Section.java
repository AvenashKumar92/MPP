package lesson2.labs.prob4;

import java.util.*;

public class Section {
	String courseName;
	int sectionNumber;
	List<TranscriptEntry> gradeSheet;
	
	public Section(int secNum, String courseName2) {
		sectionNumber=secNum;
		courseName=courseName2;
		gradeSheet=new ArrayList<TranscriptEntry>();
	}

	public Section() {
		// TODO Auto-generated constructor stub
	}
}
