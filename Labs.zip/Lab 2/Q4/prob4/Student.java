package lesson2.labs.prob4;

import java.util.*;

public class Student {
	String name;
	String id;
	List<TranscriptEntry> grades;
	
	public Student(String id, String name2) {
		name=name2;
		this.id=id;
		grades=new ArrayList<TranscriptEntry>();
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Transcript getTranscript() {
		return new Transcript(grades, this);
		
	}
}
