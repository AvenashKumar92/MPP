package Lab4.probC;

public abstract class Employee {
	protected String empId;
	
	public Employee(String empId) {
		super();
		this.empId = empId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	void print(){
		System.out.println("Employee ID: = " +empId);
	}
	
	Paycheck calcCompensation(int month, int year){
		double grossSalary=calcGrossPay(month,  year);
		
		double fica=grossSalary*Tax.FICA.getTax()/100;
		double state=grossSalary*Tax.STATE.getTax()/100;
		double local=grossSalary*Tax.LOCAL.getTax()/100;
		double medicare=grossSalary*Tax.MEDICARE.getTax()/100;
		double socialSecurity=grossSalary*Tax.SOCIAL_SECURITY.getTax()/100;
		return new Paycheck(grossSalary, fica, state, local, medicare, socialSecurity);
	}
	
	public abstract double calcGrossPay(int month, int year);
}

