package Lab4.probC;

public final class Paycheck {

	final private double grossPay;
	final private double fica;
	final private double state;
	final private double local;
	final private double medicare;
	final private double socialSecurity;
	
	
	
	public Paycheck(double grossPay, double fica, double state, double local, double medicare, double socialSecurity) {
		this.grossPay = grossPay;
		this.fica = fica;
		this.state = state;
		this.local = local;
		this.medicare = medicare;
		this.socialSecurity = socialSecurity;
	}

	void print(){
		System.out.println("Gross Pay: = "+grossPay);
		System.out.println("Net Pay: = "+getNetPay());
		
		System.out.println("----------------------- Deduction Details --------------------------");
		System.out.println("FICA Tax: = "+fica);
		System.out.println("State Tax: = "+state);
		System.out.println("Local Tax: = "+local);
		System.out.println("Medicare Tax: = "+medicare);
		System.out.println("Social Security Tax: = "+socialSecurity);
	}
	
	double getNetPay(){
		double totalDeduction=fica+state+socialSecurity+medicare+local;
		return grossPay - totalDeduction;
	}

	public double getGrossPay() {
		return grossPay;
	}

	public double getFica() {
		return fica;
	}

	public double getState() {
		return state;
	}

	public double getLocal() {
		return local;
	}

	public double getMedicare() {
		return medicare;
	}

	public double getSocialSecurity() {
		return socialSecurity;
	}
	
	
}
