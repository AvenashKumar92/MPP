package Lab4.probC;

import java.util.ArrayList;

public class Commissioned extends Employee {
	private double commission;
	private double baseSalary;
	private ArrayList<Order> orders;
	
	public Commissioned(String empId, double commission, double baseSalary) {
		super(empId);
		this.commission = commission;
		this.baseSalary = baseSalary;
		orders=new ArrayList<Order>();
	}
	
	public ArrayList<Order> getOrders() {
		return orders;
	}

	public void addOrder(Order order) {
		orders.add(order);
	}

	public double getCommission() {
		return commission;
	}
	public void setCommission(double commission) {
		this.commission = commission;
	}
	public double getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(double baseSalary) {
		this.baseSalary = baseSalary;
	}

	@Override
	public double calcGrossPay(int month, int year) {
		if(month<1 || month>12)
			throw new IllegalArgumentException("Month should be in range of 1 to 12");
		
		int pervMonth=month-1;
		
		if(pervMonth<1)
		{
			pervMonth=12;
			year=year-1;
		}
		
		return baseSalary+findTotalCommisionOnAGivenMonthAndYear(pervMonth, year);
	}
	
	public ArrayList<Order> findOrderOfGivenMonthAndYear(int month, int year){
		ArrayList<Order> tempOrders=new ArrayList<Order>();
		
		for(Order order:orders){
			if(order.getOrderDate().getMonth().getValue()==month && order.getOrderDate().getYear()==year){
				tempOrders.add(order);
			}
		}
		return tempOrders;
	}
	
	public double findTotalCommisionOnAGivenMonthAndYear(int month, int year){
		ArrayList<Order> orders = findOrderOfGivenMonthAndYear (month, year);
		double totalCommision=0.0;
		for(Order order: orders){
			totalCommision+=order.getOrderAmount();
		}
		return (totalCommision*commission)/100.0;
	}
	
}
