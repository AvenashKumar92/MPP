package Lab4.probC;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

/**
 * Hello world!
 *
 */
public class App 
{
	ArrayList<Employee> employees=new ArrayList<Employee>();
    public static void main( String[] args )
    {
        App a=new App();
        a.fillEmployeeData();
        a.printEmployeesInfo(1, 2018);
    }
    
    public void printEmployeesInfo(int month, int year){
    	for(Employee e:employees){
    		e.print();
    		Paycheck payCkeck=e.calcCompensation(month, year);
    		payCkeck.print();
    		System.out.println();
    	}
    }
    
    public void fillEmployeeData(){
    	
    	//Hourly employees
    	employees.add(new Hourly("H_1", 20.0, 4));
    	employees.add(new Hourly("H_2", 15.0, 7));
    	employees.add(new Hourly("H_3", 25.0, 5));
    	employees.add(new Hourly("H_4", 30.0, 6));
    	
    	//Salaried Employees
    	employees.add(new Salaried("S_1", 2000.0));
    	employees.add(new Salaried("S_2", 3000.0));
    	employees.add(new Salaried("S_3", 5000.0));
    	
    	//Orders
		Order orders[]={new Order("O_1",LocalDate.parse("2017-12-20"), 20 ),
    			new Order("O_2",LocalDate.parse("2016-12-04"), 10 ),
    			new Order("O_3",LocalDate.parse("2017-12-01"), 20 ),
    			new Order("O_4",LocalDate.parse("2017-12-03"), 30 )};

    	Commissioned commissioned[]={new Commissioned("C_1", 5, 200.0),
    			new Commissioned("C_2", 2, 200.0),
    			new Commissioned("C_3", 3, 300.0)};
    	
    	commissioned[0].addOrder(orders[0]);
    	commissioned[0].addOrder(orders[1]);
    	commissioned[1].addOrder(orders[2]);
    	commissioned[2].addOrder(orders[3]);
    	
    	//Commissioned Employees
    	employees.add(commissioned[0]);
    	employees.add(commissioned[1]);
    	employees.add(commissioned[2]);
    }
}
