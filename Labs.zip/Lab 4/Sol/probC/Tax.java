package Lab4.probC;

public enum Tax {
	FICA(23),
	STATE(5),
	LOCAL(1),
	MEDICARE(3),
	SOCIAL_SECURITY(7.5);
	
	private double tax;
	 
	Tax(double tax) {
        this.tax = tax;
    }

	public double getTax() {
		return tax;
	}
}
