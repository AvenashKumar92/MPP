package Lab4.probE;

public abstract class Account {
	abstract String getAccount();
	abstract double getBalance();
	abstract double computeUpdatedBalance();
}
