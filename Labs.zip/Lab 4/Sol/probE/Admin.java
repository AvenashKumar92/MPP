package Lab4.probE;

import java.util.List;

import Lab4.probE.Employee;

public class Admin {
	public static double computeUpdatedBalanceSum(List<Employee> list) {
		double updatedBalance=0.0;
		for(Employee e:list){
			updatedBalance+=e.computeUpdatedBalanceSum();
		}
		return updatedBalance;
	}
}
