package Lab4.probE;

public class CheckingAccount extends Account {

	private double balance;
	private double monthlyFee;
	private String accId;
	
	public CheckingAccount(String accId, double monthlyFee, double balance) {
		super();
		this.balance = balance;
		this.monthlyFee = monthlyFee;
		this.accId = accId;
	}

	
	@Override
	String getAccount() {
		return accId;
	}

	@Override
	double getBalance() {
		return balance;
	}

	@Override
	double computeUpdatedBalance() {
		return balance-monthlyFee;
	}
}
