package Lab4.probE;

public class SavingsAccount extends Account {

	private double balance;
	private double interestRate;
	private String accId;
	
	public SavingsAccount(String accId, double interestRate, double balance) {
		super();
		this.balance = balance;
		this.interestRate = interestRate;
		this.accId = accId;
	}

	@Override
	String getAccount() {
		return accId;
	}

	@Override
	double getBalance() {
		return balance;
	}

	@Override
	double computeUpdatedBalance() {
		return balance+(interestRate*balance);
	}

	
}
