package assignment.lesson4.probB;

import java.util.List;

public class Commissioned extends Employee{
	private double commission;
	private double baseSalary;
	private List<Order> orderList;

	public Commissioned(String empId, double commission, double baseSalary, List<Order> orderList){
		super(empId);
		this.commission = commission;
		this.baseSalary = baseSalary;
		this.orderList = orderList;
	}

	@Override
	public double calcGrossPay(int month, int year) {
		double totalOrder = 0;
		for(Order o:orderList){
			if(o.getOrderDate().getMonthValue()==month-1 && o.getOrderDate().getYear()==year){
				totalOrder = totalOrder+o.getOrderAmount();
			}
		}
		return baseSalary+(totalOrder*commission);
	}

}
