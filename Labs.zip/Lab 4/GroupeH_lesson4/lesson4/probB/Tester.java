package assignment.lesson4.probB;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Tester {
	public static void main(String[] args) {
		Employee hrEmp = new Hourly("GP1001", 50.5, 30);
		Employee salEmp = new Salaried("TG1001", 5000);

		Order o1 = new Order("A12", LocalDate.of(2017, 9, 5), 100.6);
		Order o2 = new Order("B12", LocalDate.of(2017, 9, 9), 200.6);
		Order o3 = new Order("C12", LocalDate.of(2016, 9, 22), 300.6);
		Order o4 = new Order("E12", LocalDate.of(2017, 9, 7), 400.6);
		Order o5 = new Order("Y12", LocalDate.of(2017, 9, 30), 500.6);
		Order o6 = new Order("D12", LocalDate.of(2017, 9, 13), 600.6);
		List<Order> orderList = new ArrayList<>();
		orderList.add(o1);
		orderList.add(o2);
		orderList.add(o3);
		orderList.add(o4);
		orderList.add(o5);
		orderList.add(o6);

		Employee comEmp = new Commissioned("NB1100", 0.2, 2000, orderList);
		hrEmp.print();
		hrEmp.calcCompensation(10, 2017).print();

		System.out.println("\n\n---Salary Employee----");
		salEmp.print();
		salEmp.calcCompensation(9, 2017).print();

		System.out.println("\n\n---Commissioned Employee----");
		comEmp.print();
		comEmp.calcCompensation(10, 2017).print();
	}
}

/*Input and Output:
	Output:
		Employee ID: GP1001
		Gross Pay: 6060.0
		Net Pay: 3666.2999999999997
		Taxes-->
		FICA: 23.0%
		State: 5.0%
		Local: 1.0%
		Medicare: 3.0%
		Social Securuty: 7.5%
		Total Tax: 2393.7000000000003


		---Salary Employee----
		Employee ID: TG1001
		Gross Pay: 5000.0
		Net Pay: 3024.9999999999995
		Taxes-->
		FICA: 23.0%
		State: 5.0%
		Local: 1.0%
		Medicare: 3.0%
		Social Securuty: 7.5%
		Total Tax: 1975.0000000000005


		---Commissioned Employee----
		Employee ID: NB1100
		Gross Pay: 2360.6
		Net Pay: 1428.1629999999998
		Taxes-->
		FICA: 23.0%
		State: 5.0%
		Local: 1.0%
		Medicare: 3.0%
		Social Securuty: 7.5%
		Total Tax: 932.4370000000001
*/

