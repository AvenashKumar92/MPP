package assignment.lesson4.probB;

public abstract class Employee {
	private String empId;

	public Employee(String empId){
		this.empId = empId;
	}

	public void print(){
		System.out.println("Employee ID: "+empId);
	}

	public PayCheck calcCompensation(int month, int year){
		double grossPay = calcGrossPay(month, year);
		PayCheck payCheck = new PayCheck(grossPay);
		//payCheck.getNetPay();
		return payCheck;
	}

	public abstract double calcGrossPay(int month, int year);

	@Override
	public String toString(){
		return empId;
	}
}
