package assignment.lesson4.probB;

public final class PayCheck {
	private double grossPay;
	private final double fica = .23;
	private final double state = .05;
	private final double local = .01;
	private final double medicare = .03;
	private final double socialsecuruty =.075;

	public PayCheck(double grossPay){
		this.grossPay = grossPay;
	}

	public double getGrossPay() {
		return grossPay;
	}

	public double getFica() {
		return fica;
	}

	public double getState() {
		return state;
	}

	public double getLocal() {
		return local;
	}

	public double getMedicare() {
		return medicare;
	}

	public double getSocialsecuruty() {
		return socialsecuruty;
	}

	public double getNetPay(){
		double netPay = grossPay - grossPay*(fica+state+local+medicare+socialsecuruty);
		return netPay;
	}
	public void print(){
		System.out.println(toString());
	}
	@Override
	public String toString(){
		double totalTax = grossPay*(fica+state+local+medicare+socialsecuruty);
		return "Gross Pay: "+grossPay+"\nNet Pay: "+this.getNetPay()+"\nTaxes-->"+"\nFICA: "+fica*100+"%"+"\nState: "+state*100+"%"+
				"\nLocal: "+local*100+"%"+"\nMedicare: "+medicare*100+"%"+"\nSocial Security: "+socialsecuruty*100+"%"+"\nTotal Tax: "+totalTax;
	}
}
