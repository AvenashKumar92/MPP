package Lab3.prob2;

import java.util.ArrayList;
import java.util.List;

public class App {
	public static void main(String [] args){
		
		Building building1 = new Building("Argerio", 1000);
		building1.addNewApartment(new Apartment("A 1", 500));
		building1.addNewApartment(new Apartment("A 2", 500));
		building1.addNewApartment(new Apartment("A 3", 500));
		building1.addNewApartment(new Apartment("A 4", 500));
		
		Building building2 = new Building("Piece Place", 1000);
		building1.addNewApartment(new Apartment("P 1", 1000));
		building1.addNewApartment(new Apartment("P 2", 1000));
		building1.addNewApartment(new Apartment("P 3", 1000));
		building1.addNewApartment(new Apartment("P 4", 1000));
		
		ArrayList<Building> buildings=new ArrayList<Building>();
		buildings.add(building1);
		buildings.add(building2);

		System.out.println("Total income of landlord is " + calTotalIncome(buildings));
	}
	
	public static double calTotalIncome(ArrayList<Building> buildings){
		double totalIncome=0.0;
		for(Building building:buildings){
			totalIncome+=building.calculateProfit();
		}
		return totalIncome;
	}
}
