package Lab3.prob2;

import java.util.ArrayList;
import java.util.List;

public class Building {
	String name;
	double maintenanceCost;
	private List<Apartment> apartments;

	
	/*Disable default constructor*/
	private Building(){
	
	}
	Building(String name, double maintenanceCost)	{
		this.name=name;
		this.maintenanceCost=maintenanceCost;
		apartments=new ArrayList<Apartment>();
	}
	public List<Apartment> getApartments() {
		return apartments;
	}

	public void setApartments(List<Apartment> appartments) {
		this.apartments = appartments;
	}

	public double getMaintenanceCost() {
		return maintenanceCost;
	}

	public void setMaintenanceCost(double maintenanceCost) {
		this.maintenanceCost = maintenanceCost;
	}	
	
	public double calculateProfit(){
		double rentalFees=0.0;
		for(Apartment apartment:apartments)	{
			rentalFees+=apartment.getRentalFee();
		}
		return rentalFees-maintenanceCost;
	}
	
	private Apartment findApartment(String name){
		for(Apartment apt:apartments){
			if(name.equals(apt.getName()))
				return apt;
		}
		return null;
	}
	
	public void addNewApartment(Apartment appartment){
		Apartment apt=findApartment(appartment.getName());
		
		//When apartment is not found		
		if(apt==null)
			apartments.add(appartment);
		
		//Update: rental fees otherwise
		else
			apt.setRentalFee(appartment.getRentalFee());
	}
}
