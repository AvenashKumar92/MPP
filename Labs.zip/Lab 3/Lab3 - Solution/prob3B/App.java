package Lab3.prob3B;

public class App {

	static public void main(String [] args){
		
		double radius=2.0;
		Circle circle =new Circle(radius);
		System.out.println("Area of Circle: = " + circle.computeArea());
		
		double height=8.0;
		Cylinder cylinder=new Cylinder(circle, height);
		System.out.println("Volume of Cylinder: = " + cylinder.computeVolume());
	}
}
