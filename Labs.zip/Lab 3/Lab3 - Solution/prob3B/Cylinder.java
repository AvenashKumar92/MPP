package Lab3.prob3B;

public class Cylinder {	
	
	Circle circle;
	protected double height;
	
	Cylinder(){
		
	}
	Cylinder(double radius, double height){
		circle=new Circle(radius);
		this.height=height;
	}
	
	Cylinder (Circle circle, double height){
		this.circle=circle;
		this.height=height;
	}
	
	
	public void setHeight(double height) {
		this.height = height;
	}
	
	public double computeVolume(){
		return circle.computeArea()*height;
	}
}
