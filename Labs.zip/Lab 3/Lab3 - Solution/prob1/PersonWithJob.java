package Lab3.prob1;

public class PersonWithJob {
	
	private double salary;
	private Person person;
	
	public double getSalary() {
		return salary;
	}
	public Person getPerson()	{
		return person;
	}
	PersonWithJob(String n, double s) {
		person=new Person(n);
		salary = s;
	}
	PersonWithJob(Person person) {
		this.person=person;
		salary = 0.0;
	}
	
	@Override
	public boolean equals(Object aPerson) {
		if(aPerson == null) return false;
		if(aPerson instanceof PersonWithJob){
			PersonWithJob pJ=(PersonWithJob)aPerson;
			return this.getPerson().getName().equals(pJ.getPerson().getName()) &&
			this.getSalary()==pJ.getSalary();
		}
		else if(aPerson instanceof Person){
			Person p=(Person)aPerson;
			return this.getPerson().getName().equals(p.getName());
		}
		else
			return false;
	}
	public static void main(String[] args) {
		PersonWithJob p1 = new PersonWithJob("Joe", 30000);
		Person p2 = new Person("Joe");
		//As PersonsWithJobs, p1 should be equal to p2
		System.out.println("p1.equals(p1)? " + p1.equals(p1));
		System.out.println("p2.equals(p2)? " + p2.equals(p2));
		System.out.println("p1.equals(p2)? " + p1.equals(p2));
		System.out.println("p2.equals(p1)? " + p2.equals(p1));
	}


}
