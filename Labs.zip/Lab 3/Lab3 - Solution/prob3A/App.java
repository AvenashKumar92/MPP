package Lab3.prob3A;

public class App {

	public static void main(String [] args){
		double radius=2.0;
		Circle circle = new Circle(radius);
		System.out.println("Area of the Circle: = "+circle.computeArea());
		
		double height=8.0;
		Cylinder cylinder = new Cylinder(radius, height);
		System.out.println("Area of the Cylinder: = "+cylinder.computeVolume());
	}
}
