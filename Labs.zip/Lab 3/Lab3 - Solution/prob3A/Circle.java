package Lab3.prob3A;

public class Circle extends Cylinder{

	
	Circle(double radius) {
		super();
		this.radius=radius;
	}
	
	public double computeArea(){
		return Math.PI*radius*radius;
	}
}
