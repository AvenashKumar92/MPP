package Lab3.prob4;

public class Trailer extends Property {

	@Override
	public void computeTotalRent() {
		rent=500;
	}
	
	@Override
	public String toString() {
		return "Trailer Information:\n"+super.toString();
	}
}
