package Lab3.prob4;

public abstract class Property {
	protected double rent;
	protected Address address;
	
	public Property(){
	}
	
	Property(Address address){
		this.address=address;
	}
	
	public double getRent() {
		return rent;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public abstract void computeTotalRent();
	
	@Override
	public String toString()
	{
		return "Rent:="+rent+"\n"+address.toString();
	}
}
