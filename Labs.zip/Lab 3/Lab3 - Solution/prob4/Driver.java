package Lab3.prob4;

public class Driver {

	public static void main(String[] args) {

		//Part 1: Calculate total rent
		Property[] objects = { new House(9000), new Condo(2), new Trailer() };
		double totalRent = Admin.computeTotalRent(objects);
		System.out.println(totalRent);
		System.out.println();
		
		//Part 2: Print/List all properties of input city
		Address address=new Address();
		address.setCountry("USA");
		address.setState("IOWA");
		address.setCity("Fairfield");
		address.setStreetAddress("1000 N. 4th street");
		address.setRoomNumber(209);
		
		House h=new House(9000);
		h.setAddress(address);
		
		Condo condo=new Condo(2);
		condo.setAddress(address);
		
		Trailer trailer=new Trailer();
		trailer.setAddress(address);
		
		Property[] properties = { h, condo, trailer};
		Admin.computeTotalRent(properties);
		Admin.listAllPropertiesOf(properties, "Fairfield");
	}
}
