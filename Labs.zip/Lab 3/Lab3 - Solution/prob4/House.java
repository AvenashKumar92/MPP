package Lab3.prob4;

public class House extends Property{

	int lotSize;
	
	
	public House(int lotSize) {
		super();
		this.lotSize = lotSize;
	}


	@Override
	public void computeTotalRent() {
		rent = 0.1*lotSize;	
	}


	@Override
	public String toString() {
		return "House Information:\nLot Size: =" + lotSize+"\n"+super.toString();
	}

}
