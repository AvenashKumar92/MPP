package Lab3.prob4;

public class Admin {
	public static double computeTotalRent(Property[] properties) {
		double totalRent = 0;
		for (Property p : properties) {
			p.computeTotalRent();
			totalRent+=p.getRent();
		}
		return totalRent;
	}
	
	public static void listAllPropertiesOf(Property[] properties, String cityName){
		for(Property p:properties){
			if(p.getAddress().getCity().equals(cityName)){
				System.out.println(p.toString());
				System.out.println();
			}
		}
	}
}
