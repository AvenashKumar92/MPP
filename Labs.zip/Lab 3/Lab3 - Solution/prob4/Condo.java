package Lab3.prob4;

public class Condo extends Property {

	int totalFloors;
	
	Condo(int totalFloors) {
		super();
		this.totalFloors=totalFloors;
	}

	@Override
	public void computeTotalRent() {
		rent=400*totalFloors;
	}

	@Override
	public String toString() {
		return "Condo Information:\nTotal Floors: =" + totalFloors+"\n"+super.toString();
	}
}
