package prob3;

import java.util.function.BiFunction;

/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class Main
{
    static BiFunction<Double, Double, Double> powCal=(x,y)->Math.pow(x,y);

    public static void main(String [] args){
        System.out.println(powCal.apply(2.0, 3.0));
    }
}
