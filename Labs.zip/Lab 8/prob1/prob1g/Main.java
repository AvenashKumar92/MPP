package prob1.prob1g;

import java.util.function.Predicate;

/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class Main
{
    public static void main(String[] args)
    {
        final MyClass cl = new MyClass();


        Predicate<MyClass> p=new Predicate<MyClass>()
        {
            public boolean test(MyClass myClass)
            {
                return myClass.myMethod(cl);
            }
        };

        System.out.println(p.test(cl));
    }
}
