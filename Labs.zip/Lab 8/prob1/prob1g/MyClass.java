package prob1.prob1g;


/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class MyClass
{
    public boolean myMethod(MyClass cl){
        if(this==cl)
            return true;
        else
            return false;
    }

}
