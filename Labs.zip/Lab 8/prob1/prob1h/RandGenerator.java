package prob1.prob1h;

import java.util.function.Supplier;

/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class RandGenerator
{
    Double generateRandom(){
        Supplier<Double> rand=new Supplier<Double>()
        {
            @Override
            public Double get()
            {
                return Math.random();
            }
        };
        return rand.get();
    }
}
