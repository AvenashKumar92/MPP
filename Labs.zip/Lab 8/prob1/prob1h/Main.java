package prob1.prob1h;

import java.util.function.Supplier;

/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class Main
{
    public static void main(String [] args){
        Supplier<Double> randGenerator=()-> Math.random();
        System.out.println("Lambda Expression Rnd Number: "+randGenerator.get());

        RandGenerator rnd=new RandGenerator();
        System.out.println("Inner Class Rnd Number: "+rnd.generateRandom());
    }
}
