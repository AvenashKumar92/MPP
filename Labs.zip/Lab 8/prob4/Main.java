import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Created by Avenash_2 on 3/15/2018.
 */
public class Main
{
    public static void main(String [] args){
        List<String> words=new ArrayList<>();
        words.add("Hello");
        words.add("World");
        words.add("and");
        words.add("Mum");
        System.out.println(countWords(words, 'o', 'o', 5));
    }

    public static int countWords(List<String> words, char c, char d, int len){
        return words.stream().filter(new Predicate<String>()
        {
            @Override
            public boolean test(String s)
            {
                return s.length()==len;
            }
        }).filter(new Predicate<String>()
        {
            @Override
            public boolean test(String s)
            {
                return s.contains(""+c);
            }
        }).filter(new Predicate<String>()
        {
            @Override
            public boolean test(String s)
            {
                return !s.contains(""+d);
            }
        }).collect(Collectors.toList()).size();
    }
}
