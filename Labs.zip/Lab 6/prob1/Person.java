package prob1;

/**
 * Created by Avenash_2 on 3/4/2018.
 */
public final class Person
{
    final String name;
    final Address address;

    public Person(String name, Address address)
    {
        this.name = name;
        this.address = address;
    }

    @Override
    public String toString()
    {
        return name.trim() + "\n" + address.toString();
    }

    public String getName()
    {
        return name;
    }

    public Address getAddress()
    {
        return address;
    }
}
