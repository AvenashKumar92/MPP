package prob1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import prob1.rulesets.RuleException;
import prob1.rulesets.RuleSetFactory;

public class MyApp extends Application {

    Label lblName=new Label("Name");
    Label lblStreet=new Label("Street");
    Label lblCity=new Label("City");
    Label lblState=new Label("State");
    Label lblZip=new Label("Zip");

    @FXML
    private Button btnSubmit;

    @FXML
    private TextField txtName=new TextField();

    @FXML
    private TextField txtCity=new TextField();

    @FXML
    private TextField txtState=new TextField();

    @FXML
    private TextField txtStreet=new TextField();

    @FXML
    private TextField txtZipCode=new TextField();

    private Person person;

    void initControllers(){
        btnSubmit=new Button("Submit");
        btnSubmit.setOnAction(this::handleButtonAction);
    }

    @Override
    public void start(Stage primaryStage) throws Exception{
        initControllers();
        primaryStage.setTitle("Address Form");

        //VBox: Name
        VBox vBoxName=new VBox();
        vBoxName.setAlignment(Pos.TOP_LEFT);
        vBoxName.getChildren().add(lblName);
        vBoxName.getChildren().add(txtName);

        //VBox: Street
        VBox vBoxStreet=new VBox();
        vBoxStreet.setAlignment(Pos.TOP_LEFT);
        vBoxStreet.getChildren().add(lblStreet);
        vBoxStreet.getChildren().add(txtStreet);

        //VBox: City
        VBox vBoxCity=new VBox();
        vBoxCity.setAlignment(Pos.TOP_LEFT);
        vBoxCity.getChildren().add(lblCity);
        vBoxCity.getChildren().add(txtCity);

        //VBox: State
        VBox vBoxState=new VBox();
        vBoxState.setAlignment(Pos.TOP_LEFT);
        vBoxState.getChildren().add(lblState);
        vBoxState.getChildren().add(txtState);

        //VBox: Zip
        VBox vBoxZip=new VBox();
        vBoxZip.setAlignment(Pos.TOP_LEFT);
        vBoxZip.getChildren().add(lblZip);
        vBoxZip.getChildren().add(txtZipCode);

        //HBox: Name, Street, City
        HBox hBox1 = new HBox();
        hBox1.setSpacing(15.0);
        hBox1.setAlignment(Pos.CENTER);
        hBox1.getChildren().add(vBoxName);
        hBox1.getChildren().add(vBoxStreet);
        hBox1.getChildren().add(vBoxCity);

        //HBox: State, Zip
        HBox hBox2 = new HBox();
        hBox2.setSpacing(15.0);
        hBox2.setAlignment(Pos.CENTER);
        hBox2.getChildren().add(vBoxState);
        hBox2.getChildren().add(vBoxZip);

        //HBox: Button
        VBox hBox3 = new VBox();
        hBox3.setAlignment(Pos.BOTTOM_CENTER);
        hBox3.getChildren().add(btnSubmit);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.TOP_CENTER);
        grid.setHgap(20);
        grid.setVgap(10);
        grid.add(hBox1,0, 0, 3, 1);
        grid.add(hBox2,0, 1, 3, 1);
        grid.add(hBox3, 0, 2, 3, 5);

        primaryStage.setScene(new Scene(grid, 550, 150));
        primaryStage.show();

    }


    @FXML
    private void handleButtonAction(ActionEvent event) {

        try
        {
            Address address=new Address(txtCity.getText(),
                    txtState.getText(), txtZipCode.getText(), txtStreet.getText());

            person=new Person(txtName.getText(), address);
            RuleSetFactory.getRuleSet(MyApp.this).applyRules(this);
            System.out.println(person);
            clearFields();
        }
        catch(RuleException e)
        {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Message");
            alert.setHeaderText(null);
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }

    }

    private void clearFields()
    {
        txtName.setText("");
        txtState.setText("");
        txtCity.setText("");
        txtStreet.setText("");
        txtZipCode.setText("");
    }

    public Person getPerson(){
        return person;
    }
    public static void main(String[] args) {
        launch(args);
    }
}
