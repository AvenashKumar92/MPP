package prob1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controller {
    @FXML
    private Button btnSubmit;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtCountry;

    @FXML
    private TextField txtState;

    @FXML
    private TextField txtStreet;

    @FXML
    private TextField txtZipCode;

    private void initialize()
    {
        // Handle Button event.
        btnSubmit.setOnAction(this::handleButtonAction);
    }
    @FXML
    private void handleButtonAction(ActionEvent event) {
        // Button was clicked, do something...
        //outputTextArea.appendText("Button Action\n");
    }
}
