package prob1;

/**
 * Created by Avenash_2 on 3/4/2018.
 */
public final class Address
{
    private final String city;
    private final String state;
    private final String zipCode;
    private final String street;

    public Address(String city, String state, String zipCode, String street)
    {
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.street = street;
    }
    public String getStreet(){
        return street;
    }
    public String getCity()
    {
        return city;
    }

    public String getState()
    {
        return state;
    }

    public String getZipCode()
    {
        return zipCode;
    }

    @Override
    public String toString()
    {
        String str=street.trim()+"\n";
        str+=city.trim()+", ";
        str+=state.trim()+" ";
        str+=zipCode.trim();
        return str;
    }
}
