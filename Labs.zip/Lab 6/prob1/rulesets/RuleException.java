package prob1.rulesets;

/**
 * Created by Avenash_2 on 3/4/2018.
 */
public class RuleException extends Exception {
    public RuleException() {
        super();
    }
    public RuleException(String msg) {
        super(msg);
    }
}