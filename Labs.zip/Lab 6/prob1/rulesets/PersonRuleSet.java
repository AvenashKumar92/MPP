package prob1.rulesets;

import javafx.application.Application;
import prob1.Address;
import prob1.MyApp;
import prob1.Person;

/**
 * Created by Avenash_2 on 3/4/2018.
 */
public class PersonRuleSet implements RuleSet
{

    Person person;

    @Override
    public void applyRules(Application application) throws RuleException
    {
        MyApp a=(MyApp)application;
        person = a.getPerson();
        nonemptyRule();
        zipCodeNumeric();
    }

    private void zipCodeNumeric() throws RuleException
    {
        try
        {
            Integer.parseInt(person.getAddress().getZipCode().trim());
        }
        catch (NumberFormatException e){
            throw new RuleException("Zip code should be numeric");
        }
    }

    private void nonemptyRule() throws RuleException
    {
        Address address=person.getAddress();
        if(person.getName().trim().isEmpty() ||
                address.getCity().trim().isEmpty() ||
                address.getState().trim().isEmpty() ||
                address.getStreet().trim().isEmpty() ||
                address.getZipCode().trim().isEmpty())
            throw new RuleException("All fields must be nonempty");
    }


}
