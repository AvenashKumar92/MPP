package prob1.rulesets;

import javafx.application.Application;
import prob1.MyApp;

import java.util.HashMap;

final public class RuleSetFactory {
    private RuleSetFactory(){}
    static HashMap<Class<? extends Application>, RuleSet> map = new HashMap<Class<? extends Application>, RuleSet>();
    static {
        map.put(MyApp.class, new PersonRuleSet());
    }
    public static RuleSet getRuleSet(Application c) {
        Class<? extends Application> cl = c.getClass();
        if(!map.containsKey(cl)) {
            throw new IllegalArgumentException(
                    "No RuleSet found for this Application");
        }
        return map.get(cl);
    }
}
