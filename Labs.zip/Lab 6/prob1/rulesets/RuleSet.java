package prob1.rulesets;

import javafx.application.Application;

/**
 * Created by Avenash_2 on 3/4/2018.
 */
public interface RuleSet
{
        public void applyRules(Application ob) throws RuleException;
}
