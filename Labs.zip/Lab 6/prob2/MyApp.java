package prob2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import static javafx.application.Application.launch;

/**
 * Created by Avenash_2 on 3/4/2018.
 */
public class MyApp extends Application
{
    Label lblInput;
    TextField txtInput;

    Label lblOutput;
    TextField txtOutput;

    Button btnCountLetters;
    Button btnReverseLetters;
    Button btnRemoveDuplicates;

    @Override
    public void start(Stage primaryStage) throws Exception{
        initControllers();
        primaryStage.setTitle("String Utility");

        //VBox: Button
        VBox vBoxButtons=new VBox();
        vBoxButtons.setAlignment(Pos.TOP_LEFT);
        vBoxButtons.setSpacing(20);
        vBoxButtons.getChildren().add(btnCountLetters);
        vBoxButtons.getChildren().add(btnReverseLetters);
        vBoxButtons.getChildren().add(btnRemoveDuplicates);

        //VBox: Textboxes
        VBox vBoxLabelsAndTxtFields=new VBox();
        vBoxLabelsAndTxtFields.setAlignment(Pos.CENTER);
        vBoxLabelsAndTxtFields.getChildren().add(lblInput);
        vBoxLabelsAndTxtFields.getChildren().add(txtInput);
        vBoxLabelsAndTxtFields.getChildren().add(lblOutput);
        vBoxLabelsAndTxtFields.getChildren().add(txtOutput);


        GridPane grid = new GridPane();
        grid.setAlignment(Pos.TOP_CENTER);
        grid.setHgap(20);
        grid.setVgap(10);
        grid.add(vBoxButtons,0, 0, 1, 3);
        grid.add(vBoxLabelsAndTxtFields,1, 0, 1, 3);

        primaryStage.setScene(new Scene(grid, 550, 150));
        primaryStage.show();

    }
    @FXML
    private void btnEventCountLetters(ActionEvent event) {
        String inputText=txtInput.getText().trim();
        txtOutput.setText(String.valueOf(inputText.length()));
    }

    private String reverseString(String inputStr)
    {
        String reversedString="";
        for(int i=inputStr.length()-1; i>=0; i-- ){
            reversedString+=inputStr.charAt(i);
        }
        return reversedString;
    }

    @FXML
    private void btnEventReverseLetters(ActionEvent event) {
        String inputText=txtInput.getText().trim();
        txtOutput.setText(reverseString(inputText));
    }
    @FXML
    private void btnEventRemoveDuplicates(ActionEvent event) {
        String inputText=txtInput.getText().trim();
        txtOutput.setText(removeDuplicates(inputText));
    }

    private String removeDuplicates(String inputText)
    {
        String outputString="";
        for(int i=0; i<inputText.length(); i++){
            if(outputString.contains(String.valueOf(inputText.charAt(i)))==false)
                outputString+=inputText.charAt(i);
        }
        return outputString;
    }

    private void initControllers()
    {
        lblInput=new Label("Input");
        txtInput=new TextField();
        lblOutput=new Label("Output");
        txtOutput=new TextField();

        btnCountLetters=new Button("Count Letters");
        btnCountLetters.setOnAction(this::btnEventCountLetters);
        btnRemoveDuplicates=new Button("Remove Duplicates");
        btnRemoveDuplicates.setOnAction(this::btnEventRemoveDuplicates);
        btnReverseLetters=new Button("Reverse Letters");
        btnReverseLetters.setOnAction(this::btnEventReverseLetters);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
