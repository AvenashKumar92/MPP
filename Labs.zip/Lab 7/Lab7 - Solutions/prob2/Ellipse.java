package prob2;

/**
 * Created by Avenash_2 on 3/13/2018.
 */
public final class Ellipse implements ClosedCurve
{
    final double a, E;

    public Ellipse(double a, double e)
    {
        this.a = a;
        E = e;
    }

    @Override
    public double computePerimeter()
    {
        return 4*a*E;
    }
}
