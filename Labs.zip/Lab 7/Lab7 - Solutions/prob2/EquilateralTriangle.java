package prob2;

/**
 * Created by Avenash_2 on 3/13/2018.
 */
public final class EquilateralTriangle implements ClosedCurve, Polygon
{
    final double side;

    public EquilateralTriangle(double side)
    {
        this.side = side;
    }


    @Override
    public double[] getSides()
    {
        return new double[]{side, side, side};
    }

    @Override
    public double computePerimeter()
    {
        return Polygon.super.computePerimeter();
    }
}
