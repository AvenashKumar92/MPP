package prob2;

/**
 * Created by Avenash_2 on 3/13/2018.
 */
public interface Polygon
{
    double[] getSides();

    default double computePerimeter(){
        double dSumOfAllSides=0.0;
        for(double d:getSides()){
            dSumOfAllSides+=d;
        }
        return dSumOfAllSides;
    }
}
