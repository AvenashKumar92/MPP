package lesson7.inclassexercises_solns.exercise_3_soln;

import java.util.function.Consumer;


public class MyConsumer implements Consumer<String> {
	private MyStringList list;
	public MyConsumer(MyStringList list) {
		this.list = list;
	}
	@Override
	public void accept(String item) {
		list.add(item);	
	}
}
