package lesson7.inclassexercises_solns.exercise_4_soln.prob2;

public abstract class Impl implements Iface1, Iface2 { // causes a compiler error bcos default method conflicts with abstract method
	
    //Implementation is required to fix it
//	public int myMethod(int x) {
//		return x;
//	}
	
	// OR
	
	public abstract int myMethod(int x);

}
