package lesson7.inclassexercises_solns.exercise_4_soln.prob2;

public interface Iface2 {
	public int myMethod(int x);
}


