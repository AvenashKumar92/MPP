package lesson7.inclassexercises_solns.exercise_4_soln.prob3;

public class Impl implements Iface1, Iface2 {
	// No compiler error is produced here if nothing is done
	// because the default method takes precedence over the static method
}
