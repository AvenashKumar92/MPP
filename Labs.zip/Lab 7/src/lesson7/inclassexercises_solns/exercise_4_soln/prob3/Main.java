package lesson7.inclassexercises_solns.exercise_4_soln.prob3;

public class Main {

	public static void main(String[] args) {
		Impl ob = new Impl();
		System.out.println(ob.myMethod2(2));
		// Prints 4 because the default method is the one that gets called and not the static method
		
		//System.out.println(Impl.myMethod(2));
		System.out.println(Iface2.myMethod(2));
	}

}
