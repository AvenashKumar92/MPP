package lesson7.inclassexercises_solns.exercise_4_soln.prob3;

public interface Iface1 {
	default int myMethod2(int x) {
		return 2 * x;
	}
}
