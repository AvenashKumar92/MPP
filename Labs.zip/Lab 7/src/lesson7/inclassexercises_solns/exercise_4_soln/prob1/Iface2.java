package lesson7.inclassexercises_solns.exercise_4_soln.prob1;

public interface Iface2 {
	default int myMethod(int x) {
		return 2 * x;
	}
}
