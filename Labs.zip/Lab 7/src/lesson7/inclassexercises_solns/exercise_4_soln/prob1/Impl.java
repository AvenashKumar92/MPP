package lesson7.inclassexercises_solns.exercise_4_soln.prob1;

public abstract class Impl implements Iface1, Iface2 { // causes a compiler error due to duplicate default methods being inherited
	
	//implementation or redeclaration is required to fix the compiler error
	// Or change one of the default method's name or parameter type
//	public int myMethod(int x) {
//		return x;
//	}
	// OR
	
	public abstract int myMethod(int x);
}
