package lesson7.inclassexercises_solns.exercise_2_soln;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		printSalesData(SalesDataConstsCompany.MICROSOFT, SalesDataConstsSalesTarget.TWENTY_MILLION);
		//printSalesData("Google", 550000000.00);
		System.out.println("\nAll constants for SalesDataConstsCompany: " + Arrays.toString(SalesDataConstsCompany.values()));
		System.out.println("All constants for SalesDataConstsSalesTarget: " + Arrays.toString(SalesDataConstsSalesTarget.values()));
	}
	
	private static void printSalesData(SalesDataConstsCompany company, SalesDataConstsSalesTarget sales_target) {
		System.out.printf("Company: %s\nSales Target: %.2f", company.strVal(), sales_target.dblVal());
	}	

}
