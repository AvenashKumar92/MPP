package lesson7.inclassexercises_solns.exercise_2_soln;

public enum SalesDataConstsCompany {
	MICROSOFT("Microsoft");
	
	private String strVal;

	SalesDataConstsCompany(String s) {
		strVal = s;
	}
	
	public String strVal() {
		return strVal;
	}
}

