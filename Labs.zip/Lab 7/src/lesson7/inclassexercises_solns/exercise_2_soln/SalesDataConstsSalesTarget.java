package lesson7.inclassexercises_solns.exercise_2_soln;

public enum SalesDataConstsSalesTarget {
	TWENTY_MILLION(20000000.00);
	
	private double dblVal;
	
	SalesDataConstsSalesTarget(double val) {
		dblVal = val;
	}
	
	public double dblVal() {
		return dblVal;
	}
}
