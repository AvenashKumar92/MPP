package lesson7.inclassexercises.exercise_2;

public class Constants {
	public static final String COMPANY = "Microsoft";
	public static final double SALES_TARGET = 20000000.00;
}
