package lesson7.lecture.defaultmethodrules.intfaceclash2;

public interface Top {
	public void myMethod(int x);
}
