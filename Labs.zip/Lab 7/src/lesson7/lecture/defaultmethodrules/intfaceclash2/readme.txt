This is an example of the Diamond Problem
with implemented interfaces

To view the uml file diamond.uml, you need
the UML Designer plug-in.