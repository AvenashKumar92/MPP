package lesson7.lecture.defaultmethodrules.inherit;

public interface SubIntface extends Intface {
	
}
