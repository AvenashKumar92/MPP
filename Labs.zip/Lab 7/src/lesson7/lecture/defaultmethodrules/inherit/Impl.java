package lesson7.lecture.defaultmethodrules.inherit;

//Impl inherits the default method from the interface
public class Impl implements Intface {
    
}
