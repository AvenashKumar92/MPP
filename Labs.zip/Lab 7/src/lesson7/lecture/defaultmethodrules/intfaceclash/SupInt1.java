package lesson7.lecture.defaultmethodrules.intfaceclash;

public interface SupInt1 {
	void myMethod(int x);
}
