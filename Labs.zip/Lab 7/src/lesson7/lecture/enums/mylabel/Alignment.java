package lesson7.lecture.enums.mylabel;

public enum Alignment {
	LEFT, CENTER, RIGHT;
}
